#include <stdio.h>

 
int main (void){

    float totalreal, tres, dinheiroamigo, brother, muitodinheiro, fixo, amigao;

    printf("\nQual o seu salario fixo?: ");
    scanf("%f",&fixo);
    
    printf("\nPor quanto voce conseguiu vender? ");
    scanf("%f",&totalreal);

    if(totalreal<=1500) {
        tres = totalreal * 0.03;
        printf("\nVoce recebera de comissao: %2.f Reais",tres);
        printf("\nCom o seu Salario fixo de: %2.f Reais ",fixo);
        printf("e com o sua Comissao de: %2.f Reais \n",tres);
        amigao = tres + fixo;
        printf("\n\nSeu dinheiro total eh de: %2.f Reais",amigao);

    } else if (totalreal>1500)
    {
        dinheiroamigo = (totalreal -1500) * 0.05;
        brother = 1500 * 0.03;
        muitodinheiro = brother + dinheiroamigo;
        printf("Voce vai receber de comissao: %2.f Reais",muitodinheiro);
    
        printf("\nCom o seu Salario fixo de: %2.f Reais ",fixo);
        printf("e com o sua Comissao de: %2.f Reais \n",muitodinheiro);
        amigao = muitodinheiro + fixo;
        printf("\n\nSeu dinheiro total eh de: %2.f Reais",amigao);
    
    }

  
}

    