#include <stdio.h>

int main (void){
    int valor1, valor2,numMaior, i;

    printf ("Digite um numero: ");
    scanf ("%d", &valor1);

    printf ("Digite outro numero: ");
    scanf ("%d", &valor2);

    if (valor1 > valor2){
        numMaior = valor1;
        valor1 = valor2;
        valor2 = numMaior;
    }
    
    
    
    for (int i= (valor1+ 1); i<valor2; i= i + 1)
    {
        printf ("%d \n", i);

    }

    printf ("########################### \n");

    for (int i=(valor2 - 1); i>valor1; i= i - 1)
    {
        printf ("%d \n", i);

    }
}
