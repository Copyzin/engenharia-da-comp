#include <stdio.h>

 
int main (void){
    //variaveis:
    float mquadrados, litros, latas, valor;

    printf("\nQuantos metros quadrados serao pintados?: ");
    scanf("%f",&mquadrados);

    litros = mquadrados /3;

    printf("\n\nVoce vai precisar de: %2.f Litros",litros);

    latas = litros/18;

    printf("\n\nLogo, voce vai precisar de: %2.f Latas",latas);

    valor = latas *80;

    printf("\n\nVoce gastara: %2.f Reais",valor);


    system ("pause");
    return 0;
} 