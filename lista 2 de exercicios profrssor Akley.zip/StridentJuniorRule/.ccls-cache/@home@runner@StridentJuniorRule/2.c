#include <stdio.h>

int main() {
  char vetores[10];
  int i, consoante = 0;
  printf("Digite até 10 caracteres: ");
  scanf("%s", vetores);
  
for (i=0; i<10; i++){
   if (vetores[i] != 'a' && vetores[i] != 'e' && vetores[i] != 'i' && vetores[i] != 'o' && vetores[i] != 'u')
   {printf("%c", vetores[i]);
   consoante = consoante + 1;
   }
}
printf("\na quantidade de consoantes é: %i", consoante);
  return 0;
}