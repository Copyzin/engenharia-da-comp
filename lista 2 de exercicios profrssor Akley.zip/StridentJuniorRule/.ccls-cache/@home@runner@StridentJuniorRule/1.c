#include <stdio.h>

int main(void) {
  int vetores[11], i;

  for (i=1; i<=10; i++)
  {
    printf("\nDigite o %d° valor: ", i);
    scanf("%d", &vetores[i]);
  }

  for (i=10; i>=1; i--){
    if (i != 1)
    printf("%d, ", vetores[i]);
    else
    printf("%d", vetores[i]);
  }

  return 0;
}