#include <stdio.h>

 
int main (void){
    float nota1, nota2, media;

    printf("Qual foi a primeira nota?: ");
    scanf("%f",&nota1);

    printf("Qual foi a segunda nota?: ");
    scanf("%f",&nota2);

    media = (nota1 + nota2)/2;

    if (media>=7){
        printf("Aprovado!");
    
    
    } else if (media<7) {
        printf("Reprovado!!");
    }












    system ("pause");
    return 0;



}