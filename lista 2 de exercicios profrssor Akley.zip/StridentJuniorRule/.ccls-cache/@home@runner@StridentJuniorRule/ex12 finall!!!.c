#include <stdio.h>

int main (void){
    int n1, n2,nMaior, i, s1, s2;
    s1 = 0;
    s2 = 0;

    printf ("Digite um numero: ");
    scanf ("%d", &n1);

    printf ("Digite outro numero: ");
    scanf ("%d", &n2);

    if (n1 > n2){
        nMaior = n1;
        n1 = n2;
        n2 = nMaior;
    }
    
    
    
    for (int i= (n1+ 1); i<n2; i= i + 1){
        printf ("%d \n", i);
        s1 = s1 + i;

    }
    printf ("A soma dos seus numeros eh: %d\n", s1);

    printf ("########################### \n");

    for (int i=(n2 - 1); i>n1; i= i - 1){
        printf ("%d \n", i);
        s2 = s2 + i;

    }
    printf ("A soma dos seus numeros eh: %d\n", s2);
}