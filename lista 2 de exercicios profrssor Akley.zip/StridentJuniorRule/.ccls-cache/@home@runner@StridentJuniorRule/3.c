//Faça  um  Programa  que  leia  20  números  inteiros  e  armazene-os  num vetor. Armazene os números pares no vetor PAR e os números IMPARES no vetor impar. Imprima os três vetores.//
#include <stdio.h>

int main(void){
    int i, num[20], par[20], impar[20], x=0, y=0;

    printf("Digite 20 numeros inteiros:\n");
    for (i=1; i<=20; i++)
    {
        printf("Digite o %d° número:", i);
        scanf("%d ",&num[i]);
    }
    
    for (i=1; i<=20; i++)
    {
        if(num[i] %2 == 0)
        {
            par[x] = num[i];
            x++;
        }
        else
        {
            impar[y] = num[i];
            y++; 
        }
     }

    printf("\nNumeros pares digitados\n");
    for (i=0; i<x; i++)
    {printf("%d ",par[i]);}

    printf("\nNumeros impares digitados\n");
    for (i=0; i<y; i++)
    {printf("%d ",impar[i]);}

    
    }