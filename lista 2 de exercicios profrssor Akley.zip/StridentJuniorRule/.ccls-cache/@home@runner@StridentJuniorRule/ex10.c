#include <stdio.h>

int main (void) {
 
    float zero;
 
    Printf("Digite um numero de 0 - 10: ");
    scanf("%f",&zero);
    do{
        
        if (zero > 10 || zero < 0)
        {
            printf ("Voce digitou um valor impossivel, por favor digite novamente: ");
            scanf ("%f", &zero);
          
        }

    }while(zero > 10 || zero < 0);

    printf ("Seu valor eh: %2.f",zero);
    


}

