#include <stdio.h>
#include <stdlib.h>

/*Faça  um  programa  que  leia  um  número  indeterminado  de  valores, correspondentes  a  notas,  encerrando  a  entrada  de  dados  quando  for informado um valor igual a -1 (que não deve ser armazenado). Após esta entrada de dados, faça:
1.Mostre a quantidade de valores que foram lidos;
2.Exiba todos os valores na ordem em que foram informados, um ao lado do outro;
3.Exiba todos os valores na ordem inversa à que foram informados, um abaixo do outro;
4.Calcule e mostre a soma dos valores;
5.Calcule e mostre a média dos valores;
6.Calcule  e  mostre  a  quantidade  de  valores   acima   da  média calculada;
7.Calcule e mostre a quantidade de valores abaixo de sete;
8.Encerre o programa com uma mensagem;
*/

int main (void){
  int  soma=0, s=0, i=0;
  float  media=0, notas[100], resposta;

  printf("Para encerrar o programa digite '-1'. \n");

  do{
    printf("\nDigite uma nota: ");
    scanf("%f", &resposta);
    if(resposta >10 || resposta<0 && resposta!=-1){
        do{
            printf("\nINVALIDO, DIGITE NOVAMENTE: ");
            scanf("%f", &resposta);
        
        }while(resposta>10 || resposta<0 && resposta!=-1);
    }
    
    
    
    if(resposta != -1){
      notas[i] = resposta;
      i++;
      s++;
      soma += resposta;
    }
    
  }while(resposta != -1);
    
  
  media = soma/s;
  
  printf("\n1.Quantidade de valores que foram lidos: %d", s);
  printf("\n2.Valores um ao lado do outro: ");
  for(int j=0; j<i; j++){
       printf("%.2f \0", notas[j]);
  }
  printf("\n3.valores na ordem inversa um abaixo do outro: ");
  for(int j=(i-1); j>=0; j--){
       printf("\n%.2f ", notas[j]);
  }
  printf("\n4.Soma dos valores: %d", soma);
  printf("\n5.Media dos valores: %.2f", media);

    //calculo dos valores acima da media
  printf("\n6.Valores acima da media calculada: ");
  for(int j=0; j<i; j++){
       if(notas[j] >= media){
           printf("%.2f \0", notas[j]);
        }
    }

    printf("\n7.Valores abaixo da media calculada: ");
    for(int j=0; j<i; j++){
       if(notas[j] < media){
           printf("%.2f \0", notas[j]);
        }
    } 

    printf("\n\nPROGRAMA ENCERRADO\n\n");
}