#include <stdio.h>
#include <stdlib.h>

int main (void)
{  
    //variaveis
    float qntganha, nhora, salarioliquido, impostorenda, inss, sindicato, salariobruto;
    //informaçoes do usuario
    
    printf("Ola, quanto voce ganha por hora trabalhada?: \n");
    scanf ("%f",&qntganha);
    
    printf("Ola, quantas horas voce trabalha no mes?: \n\n");
    scanf ("%f",&nhora);
    
  



    salariobruto = (qntganha * nhora);
    printf("1- Seu salario bruto eh de : %2.fReais\n\n",salariobruto);
     
    inss = (salariobruto * 0.08);
    printf("2- do INSS sera pago: %2.fReais\n\n",inss);
    
    impostorenda = (salariobruto * 0.11);
    printf("3- do Imposto de renda sera pago: %2.fReais\n\n",impostorenda);
    
    sindicato = (salariobruto * 0.05);
    printf("4- do Sindicato sera pago: %2.fReais\n\n",sindicato);
    
    salarioliquido = (salariobruto - inss - impostorenda - sindicato);
    printf("5- Seu salario liquido eh de : %2.fReais\n\n",salarioliquido);

    
    system ("pause");
    return 0;

}