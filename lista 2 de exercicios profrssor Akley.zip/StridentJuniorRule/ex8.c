#include <stdio.h>

int main (void)
{
   float v1, v2, v3, v4, v5, grande;
    printf("digite os 5 numeros: ");
    scanf("%f%f%f%f%f", &v1, &v2, &v3, &v4, &v5);

    grande = v1;
    if (grande<v2)
    {
        grande = v2;
    } if (grande<v3)
    {
        grande = v3;
    } if (grande<v4)
    {
        grande = v4;
    } if (grande<v5)
    {
        grande = v5;
    }
    printf("o maior numero eh o: %f",grande);



}