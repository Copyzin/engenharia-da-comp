#include <stdio.h>

int main (void){


    float valor1;


    printf("digite o primeiro valor: ");
    scanf("%f",&valor1);

   

    if(valor1>=0){
        printf("É POSITIVO");
    }else{
        printf("É NEGATIVO");
    }
}