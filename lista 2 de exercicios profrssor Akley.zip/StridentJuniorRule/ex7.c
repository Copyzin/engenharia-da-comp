#include <stdio.h>

int main (void)
{

    int numero, resto;

    printf("digite o numero: ");
    scanf("%d",&numero);

    resto = numero % 2 ;

    if(resto==0){
        printf("EH PAR");
    }else{
        printf("EH IMPAR");
    }


}