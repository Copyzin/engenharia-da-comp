#include <stdio.h>

int main (void)
{

    float valor1, valor2;


    printf("digite o primeiro valor: ");
    scanf("%f",&valor1);

    printf("digite o segundo valor: ");
    scanf("%f",&valor2);

    if(valor1>valor2){
        printf("o numero : %f é maior",valor1);
    }else{
        printf("o numero: %f é maior",valor2);
    }
    








}