#include <stdio.h>

int main (void){
    float n1, n2, n3, n4, n5, media, soma;
   
    printf("digite o numero: ");
    scanf("%f",&n1);
    
    printf("digite o numero: ");
    scanf("%f",&n2);

    printf("digite o numero: ");
    scanf("%f",&n3);

    printf("digite o numero: ");
    scanf("%f",&n4);

    printf("digite o numero: ");
    scanf("%f",&n5);

    media = (n1+n2+n3+n4+n5)/5;

    soma =(n1+n2+n3+n4+n5);
    
    
    printf("\nA MEDIA EH: %2.f",media);

    printf("\nA SOMA EH: %2.f",soma);

}