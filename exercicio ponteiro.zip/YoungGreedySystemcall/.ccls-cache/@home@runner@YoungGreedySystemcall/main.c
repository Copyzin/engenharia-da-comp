#include <stdio.h>
#include "ponteiros.h"

int main(void) {

  ponteiros(2,3,1);
  
}