#include <stdio.h>
#include <stdlib.h>


void ponteiros(int A,int B,int C){

  
  printf("A:%i B:%i C:%i \n",A,B,C);
  
  int *maior, *meio, *menor;

  
  if(A > B && A > C){
    maior=&A;
  }
  else if(A > B && A < C){
    meio=&A;
  }
  else if(A < B && A <C){
    menor=&A;
  }
  if(B > A && B > C){
    maior=&B;
  }
  else if(B > A && B < C){
    meio=&B;
  }
  else if(B < A && B > C){
  meio=&B;
  }
  else if(B < A && B < C){
    menor=&B;
  }
  if(C > A && C > B){
    maior=&C;
  }
  else if(C > A && C < B){
    meio=&C;
  }
  else if(C < A && C < B){
    menor=&C;
  }



  printf("A:%i B:%i C:%i",*maior,*meio,*menor);
  
}