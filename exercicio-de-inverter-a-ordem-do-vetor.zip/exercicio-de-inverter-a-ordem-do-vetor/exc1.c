//1.Faça um Programa que leia um vetor de 10 números reais e mostre-os na ordem inversa
#include <stdio.h>

int exe1 (void){
  
  int i;
  
  for (i=1; i<=10; i++)
  {
    printf("%d",i);
  }
 










}